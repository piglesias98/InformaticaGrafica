Teclas implementadas:

P --> puntos
L --> líneas
F --> sólido
C --> ajedrez
A --> aleatorio SOLO PARA PIRÁMIDE Y SALE NEGRO

1 --> pirámide
2 --> cubo



# Controles
## Teclas
- **Q**:exit(0)
## Modos:
- **1**:modo=POINTS
- **2**:modo=EDGES	
- **3**:modo=SOLID
- **4**:modo=SOLID_CHESS
## Iluminación
- **5**:modo=SOLID_ILLUMINATED_FLAT
- **6**:modo=SOLID_ILLUMINATED_GOURAUD
- **K**: Activar animación de iluminación
- **M**: Rotar entre distintos materiales
## Objetos:
- **P**:t_objeto=PIRAMIDE
- **C**:t_objeto=CUBO
- **O**:t_objeto=OBJETO_PLY
- **R**:t_objeto=ROTACION
     -> **E**:t_rotacion=ESFERA;
     ->**I**:t_rotacion=CILINDRO;
	  -> **N**:t_rotacion=CONO;
	  Primero a R y luego E, I, N para elegir el objeto por revolución
- **A**:t_objeto=ARTICULADO
## Animación:
- **X**: Animación automática: ON
- **Z**: Animación automática: OFF
- **F1**: Aumentar giro pantalla
- **F2**: Disminuir giro pantalla
- **F3**: Aumentar giro brazo superior
- **F4**: Disminuir giro brazo superior
- **F5**: Aumentar giro brazo inferior
- **F6**: Disminuir giro brazo inferior
- **F7**: Aumentar traslación eje x
- **F8**: Disminuir traslación eje x

**Añadido práctica 4 --> LUZ EN LA BOMBILLA DE LA LÁMPARA**


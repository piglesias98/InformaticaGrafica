Teclas:
- 'Q':exit(0)
- '1':modo=POINTS
- '2':modo=EDGES
- '3':modo=SOLID
- '4':modo=SOLID_CHESS
- 'P':t_objeto=PIRAMIDE
- 'C':t_objeto=CUBO
- 'O':t_objeto=OBJETO_PLY
- 'R':t_objeto=ROTACION
     -> 'E':t_rotacion=ESFERA;
		->'I':t_rotacion=CILINDRO;
	  -> 'N':t_rotacion=CONO;
	  
	  Primero a R y luego E, I, N para elegir el objeto por revolucióno
